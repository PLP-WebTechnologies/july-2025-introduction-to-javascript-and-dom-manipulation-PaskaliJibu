// Part 1: Variables & Conditionals
function checkAge() {
  let age = document.getElementById("ageInput").value;
  let result = document.getElementById("ageResult");
  if (age >= 18) {
    result.textContent = "✅ You are eligible to vote!";
  } else {
    result.textContent = "❌ Sorry, you must be 18 or older.";
  }
}

// Part 2: Functions
function greetUser(name) {
  document.getElementById("greetResult").textContent = `Hello, ${name}! 👋`;
}

function calculateTotal(a, b) {
  let total = a + b;
  document.getElementById("totalResult").textContent = `Total is: ${total}`;
  return total;
}

// Part 3: Loops
function showCountdown() {
  let list = document.getElementById("countdownList");
  list.innerHTML = "";
  for (let i = 5; i >= 1; i--) {
    let li = document.createElement("li");
    li.textContent = i;
    list.appendChild(li);
  }
}

function listFruits() {
  let fruits = ["🍎 Apple", "🍌 Banana", "🍇 Grapes", "🍊 Orange"];
  let list = document.getElementById("fruitList");
  list.innerHTML = "";
  fruits.forEach(fruit => {
    let li = document.createElement("li");
    li.textContent = fruit;
    list.appendChild(li);
  });
}

// Part 4: DOM Manipulation
document.getElementById("colorBtn").addEventListener("click", function() {
  document.body.style.backgroundColor = 
    document.body.style.backgroundColor === "lightyellow" ? "#f8f9fa" : "lightyellow";
});

document.getElementById("toggleBtn").addEventListener("click", function() {
  let msg = document.getElementById("toggleMessage");
  msg.style.display = msg.style.display === "none" ? "block" : "none";
});

document.getElementById("createBtn").addEventListener("click", function() {
  let newItem = document.createElement("li");
  newItem.textContent = "✨ New dynamic item added!";
  document.getElementById("dynamicList").appendChild(newItem);
});